package com.example.vehiclerentalsystem;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class BookingController {
    @FXML
    private ComboBox<String> customerIdBox;
    @FXML
    private ComboBox<String> vehicleIdBox;
    @FXML
    private DatePicker startDatePicker;
    @FXML
    private DatePicker endDatePicker;
    @FXML
    private TableView<Booking> bookingTable;
    @FXML
    private TableColumn<Booking, Integer> colBookingId;
    @FXML
    private TableColumn<Booking, Integer> colCustomerId;
    @FXML
    private TableColumn<Booking, Integer> colVehicleId;

    @FXML
    private void createBooking() {
        String customerId = customerIdBox.getValue();
        String vehicleId = vehicleIdBox.getValue();
        String startDate = startDatePicker.getValue().toString();
        String endDate = endDatePicker.getValue().toString();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO bookings (customer_id, vehicle_id, start_date, end_date) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(customerId));
            stmt.setInt(2, Integer.parseInt(vehicleId));
            stmt.setString(3, startDate);
            stmt.setString(4, endDate);
            stmt.executeUpdate();
            // Refresh bookingTable after adding
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}