package com.example.vehiclerentalsystem;

import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentController {
    @FXML
    private ComboBox<String> bookingIdBox;
    @FXML
    private Label lblAmount;
    @FXML
    private ComboBox<String> paymentMethodBox;
    @FXML
    private TableView<Payment> paymentTable;
    @FXML
    private TableColumn<Payment, Integer> colPaymentId;
    @FXML
    private TableColumn<Payment, Integer> colBookingId;

    @FXML
    private void calculateAmount() {
        // Logic to fetch and calculate amount based on booking selection
    }

    @FXML
    private void makePayment() {
        String bookingId = bookingIdBox.getValue();
        double amount = Double.parseDouble(lblAmount.getText().replace("$", ""));
        String paymentMethod = paymentMethodBox.getValue();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO payments (booking_id, amount_paid, method) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(bookingId));
            stmt.setDouble(2, amount);
            stmt.setString(3, paymentMethod);
            stmt.executeUpdate();
            // Refresh paymentTable after adding
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}