package com.example.vehiclerentalsystem;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.CheckBox;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class VehicleController {
    @FXML
    private TextField brandField;
    @FXML
    private TextField modelField;
    @FXML
    private ComboBox<String> categoryBox;
    @FXML
    private TextField priceField;
    @FXML
    private CheckBox availableCheck;
    @FXML
    private TableView<Vehicle> vehicleTable;
    @FXML
    private TableColumn<Vehicle, Integer> colId;
    @FXML
    private TableColumn<Vehicle, String> colBrand;
    @FXML
    private TableColumn<Vehicle, String> colModel;
    @FXML
    private TableColumn<Vehicle, String> colCategory;
    @FXML
    private TableColumn<Vehicle, Double> colPrice;
    @FXML
    private TableColumn<Vehicle, Boolean> colAvailable;

    @FXML
    private void addVehicle() {
        String brand = brandField.getText();
        String model = modelField.getText();
        String category = categoryBox.getValue();
        double price = Double.parseDouble(priceField.getText());
        boolean available = availableCheck.isSelected();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO vehicles (brand, model, category, price_per_day, available) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, brand);
            stmt.setString(2, model);
            stmt.setString(3, category);
            stmt.setDouble(4, price);
            stmt.setBoolean(5, available);
            stmt.executeUpdate();
            // Refresh vehicleTable after adding
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}