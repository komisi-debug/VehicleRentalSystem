package com.example.vehiclerentalsystem;

import javafx.fxml.FXML;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.PieChart;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableView;

public class ReportController {
    @FXML
    private ComboBox<String> reportTypeBox;
    @FXML
    private PieChart vehicleAvailabilityChart;
    @FXML
    private BarChart<String, Number> revenueChart;
    @FXML
    private Label totalRevenueLabel;
    @FXML
    private TableView<Report> rentalTable;

    @FXML
    private void generateReport() {
        // Logic to generate the selected report
    }
}
