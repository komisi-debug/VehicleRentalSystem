package com.example.vehiclerentalsystem;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class CustomerController {
    @FXML
    private TextField nameField;
    @FXML
    private TextField contactField;
    @FXML
    private TextField licenseField;
    @FXML
    private TableView<Customer> customerTable;
    @FXML
    private TableColumn<Customer, Integer> colId;
    @FXML
    private TableColumn<Customer, String> colName;
    @FXML
    private TableColumn<Customer, String> colContact;
    @FXML
    private TableColumn<Customer, String> colLicense;

    @FXML
    private void addCustomer() {
        // Logic to add a customer and update the table
    }
}
